% valeur de la solution au bord x=1
function res = f_1y(y)
res = sol(1,y);