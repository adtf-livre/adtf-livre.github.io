% valeur de la solution au bord x=0
function res = f_0y(y)
res = sol(0,y);