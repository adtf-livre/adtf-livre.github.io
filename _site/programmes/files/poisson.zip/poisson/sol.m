% la fonction que l'on veut �tre solution
function res = sol(x,y)
res = exp(x*y);