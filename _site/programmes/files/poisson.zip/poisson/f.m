% membre de droite dans l'�quation de Poisson
function res = f(x,y)
res = (x^2+y^2)*exp(x*y);