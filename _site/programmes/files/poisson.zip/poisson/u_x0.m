% valeur de la solution au bord y=0
function res = f_x0(x)
res = sol(x,0);