% valeur de la solution au bord y=1
function res = f_x1(x)
res = sol(x,1);