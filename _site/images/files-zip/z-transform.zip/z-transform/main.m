% calcul "� la main" la r�ponse impulsionnelle.
a0 = 1; a1 = -1.414; a2 = 1;
b1 = 1.273; b2 = -0.810;

N = 200;
ri = zeros(N+2,1);
x = zeros(N+2,1); x(3) = 1; 
for i=3:(N+2)
	ri(i) = a0*x(i) + a1*x(i-1) + a2*x(i-2) + b1*ri(i-1) + b2*ri(i-2);
end

ri = ri(3:(N+2));
plot(1:N, ri);
AXIS([1,N,-0.2, 1]);

rf = real(fft(ri));
plot(rf);

% calcul des contours
w = exp( 2i*pi/N );
a = 1;
cont1 = a * w.^(-(0:N));
y1 = czt(ri,N+1,w,a);

poles = [0.9*exp( complex(0,pi/4) ), 0.9*exp( complex(0,-pi/4) )];
zzeros = [1.1*exp( complex(0,pi/4) ), 1.1*exp( complex(0,-pi/4) )];

w = 1/(1 + 1/(10*N))*exp( 2i*pi/N );
a = 1;
cont2 = a * w.^(-(0:N));
y2 = czt(ri,N+1,w,a);

x = (0:N)/N;

% dessin des contours et des z�ros.
subplot(2,1,1);
plot( real(poles),imag(poles), 'k*', real(zzeros),imag(zzeros), 'k+', real(cont1),imag(cont1), 'k', real(cont2),imag(cont2), 'k:' );
TITLE('Contours de calcul');
LEGEND('Poles', 'Z�ros', 'contour n�1', 'contour n�2');
XLABEL('Re(z)');
YLABEL('Im(z)');

% dessin des transform�es
subplot(2,1,2);
plot( x, abs(y1), 'k' ,  x, abs(y2), 'k:' );
TITLE('Transform�e en Z sur le contour.');
XLABEL('Frequence');
YLABEL('Amplitude');

% sauvegarde l'image
saveas(gcf, '../z-transform', 'eps')
saveas(gcf, '../z-transform', 'png')