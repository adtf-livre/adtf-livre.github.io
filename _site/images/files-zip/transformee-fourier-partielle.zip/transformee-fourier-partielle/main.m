clear;

N	= 64;
ramp	= 2*pi/N * [-N/2 : N/2];
f	= exp(-ramp.^2);
f	= f - min(f);
f	= f';

% la matrice de Fourier
c = 1;
for k = -N/2 : N/2
	B(c,:) = 1/sqrt(N+1) * exp( -j * k * ramp );
	c = c + 1;
end

% on calcule les diff�rentes transform�e fractionaires
% en prenant des puissances non enti�res de la matrice de 
% fourier.
c 	= 1;
i = 1;
for n = 0 : 1/7 : 2.0
	Bn = B^n;
	fn = abs( Bn * f );
	% affiche dans une box diff�rente � chaque fois
	subplot(4,4,i);
	plot( fn, 'b' ); 		% transform�e fractionaire
	hold on; 
	plot( f, 'r--' ); 		% le signal d'origine.
	hold off;
	axis( [1 N+1 0 2] );	
	set( gca, 'Xtick', [], 'Ytick', [] );
	text( 10,1.7, sprintf( '%0.2f', n ) );	
	i = i + 1;
end

saveas(gcf, '../transformee-fourier-partielle', 'eps')
saveas(gcf, '../transformee-fourier-partielle', 'png')