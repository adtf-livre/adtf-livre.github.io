% calcule la matrice de fourir.
function B = fmatrix(N);
for k = 0:N-1
for l = 0:N-1
	B(k+1,l+1) = exp( -l * k * 2.0i * pi / N );
end
end