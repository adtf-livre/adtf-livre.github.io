CLF;
N = 32;
h = 1/N;

% un filtre gaussien
xx = -0.5:h:0.5;
f = exp( - (2.5*xx).^2  );
plot(-N/2:N/2, f, 'k:*');
XLABEL('Temps');
YLABEL('Amplitude');
% sauvegarde l'image
saveas(gcf, '../diff-types-reponses-imp', 'eps')
saveas(gcf, '../diff-types-reponses-imp', 'png')
pause;

% r�ponse fr�quencielle
sw = [N/2+1:N+1, 1:N/2 ];
P = 1024;   % pr�cision du trac�
xx_tmp = zeros(P,1);
xx_tmp(1:N/2+1) = f(N/2+1:N+1);
xx_tmp(P-N/2+1:P) = f(1:N/2);
rf = real( fft(xx_tmp) );   % la transform�e est r�elle
% on remet le tout dans le bon sens
sw = [P/2+1:P, 1:P/2];
rf = rf(sw);
frq = (-P/2+1:P/2)/P;
plot(frq, rf, 'k');
AXIS([-0.2, 0.2, -1, 22]);
XLABEL('Fr�quences');
YLABEL('Amplitude');
% sauvegarde l'image
saveas(gcf, 'diff-types-reponses-freq', 'eps')
saveas(gcf, 'diff-types-reponses-freq', 'png')
pause;

% r�ponse indicielle
ech = zeros(P, 1);  % un �chelon 
ech(P/2+1:P) = 1;
ri = real( ifft( fft(ech).*fft(xx_tmp)  ) );    % bien sur, la r�ponse est r�elle
yy = ri(P/2+1:P/2+N);
plot(1:N, yy, 'k:*');
XLABEL('Temps');
YLABEL('Amplitude');
% sauvegarde l'image
saveas(gcf, '../diff-types-reponses-ind', 'eps')
saveas(gcf, '../diff-types-reponses-ind', 'png')
