function res = fonction_trans(z)

res = (1-1.414*z+z^2) / (0.810-1.273*z+z^2);