N = 7;
W = ones(1,1);

for i=1:N
	W = [W,W;W,-W];
end

image((W+1)*128);
colormap(gray);
axis off;

saveas(gcf, '../../images/matrices-walsh', 'eps');
saveas(gcf, '../../images/matrices-walsh', 'png');