CLF;
N = 32;
% une sinusoide
x = ( 6/(N-1)*(0:N-1) )';
f = sin( x ) + rand(N,1)*0.4;
f(N+1) = 0;
subplot(2,1,1);
plot(x,f(1:N),'k*:');
title('Avant le filtrage');
g = zeros(N+1,1);
g(1) = 0.4;
g(2) = 0.2;
g(3) = 0.1;
g(N+1) = 0.2;
g(N) = 0.1;
% calcule la convol�e
res = real( ifft( fft(f).*fft(g) ) );
subplot(2,1,2);
plot(x,res(1:N),'k*:');
title('Apr�s le filtrage');

saveas(gcf, '../filtre-lissage', 'eps')
saveas(gcf, '../filtre-lissage', 'png')