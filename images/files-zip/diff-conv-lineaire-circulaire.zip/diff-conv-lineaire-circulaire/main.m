CLF;
% Montre la diff�rence entre la convolution 
% lin�aire et la convolution lin�aire.
N = 8;
% une rampe
a = (0:N-1)';
% filtre lissage
b = zeros(N,1);
b(1) = 0.5;
b(2) = 0.25;
b(N) = 0.25;
% convolution circulaire
res1 = real( ifft( fft(a).*fft(b) ) );
SUBPLOT(2,1,1);
plot(1:N, res1, 'k*:');
AXIS([1 N 0 N-2]) 
title('Convolution circulaire');
% convolution lin�aire
b(N) = 0;
b(N+1) = 0.25;
a(N+1) = 0;
res2 = real( ifft( fft(a).*fft(b) ) );
SUBPLOT(2,1,2);
plot(1:N, res2(1:N), 'k*:');
title('Convolution lin�aire');

saveas(gcf, '../diff-conv-lineaire-circulaire', 'eps')
saveas(gcf, '../diff-conv-lineaire-circulaire', 'png')