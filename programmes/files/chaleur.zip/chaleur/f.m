function res = f(x)

% fonction echelon
if x<0.3
    res = 0;
elseif x<0.7
    res = 1;
else
    res = 0;
end
